# MaintenanceApplicative
### [R6.A.06] Maintenance applicative (2025)

## r6a06_refactorisation_dirigee
TP de refactorisation de code

On a trois classes : 
customer
rental
movie

trois associations